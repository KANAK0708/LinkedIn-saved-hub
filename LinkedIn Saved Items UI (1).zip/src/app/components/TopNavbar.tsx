import { Search } from 'lucide-react';

export function TopNavbar() {
  return (
    <header className="bg-white border-b border-gray-200 sticky top-0 z-50">
      <div className="max-w-[1128px] mx-auto px-6">
        <div className="flex items-center justify-between h-[52px]">
          {/* Left Section - Logo and Search */}
          <div className="flex items-center gap-2">
            {/* LinkedIn Logo */}
            <div className="flex items-center justify-center w-[34px] h-[34px] bg-[#0A66C2] rounded">
              <svg className="w-5 h-5 text-white" viewBox="0 0 24 24" fill="currentColor">
                <path d="M20.5 2h-17A1.5 1.5 0 002 3.5v17A1.5 1.5 0 003.5 22h17a1.5 1.5 0 001.5-1.5v-17A1.5 1.5 0 0020.5 2zM8 19H5v-9h3zM6.5 8.25A1.75 1.75 0 118.3 6.5a1.78 1.78 0 01-1.8 1.75zM19 19h-3v-4.74c0-1.42-.6-1.93-1.38-1.93A1.74 1.74 0 0013 14.19a.66.66 0 000 .14V19h-3v-9h2.9v1.3a3.11 3.11 0 012.7-1.4c1.55 0 3.36.86 3.36 3.66z"></path>
              </svg>
            </div>

            {/* Search Bar */}
            <div className="relative">
              <Search className="absolute left-2 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-600" />
              <input
                type="text"
                placeholder="Search"
                className="w-[280px] pl-9 pr-3 py-1.5 bg-[#EEF3F8] text-sm rounded focus:bg-white focus:outline-none focus:ring-1 focus:ring-gray-300"
              />
            </div>
          </div>

          {/* Right Section - Navigation Icons */}
          <nav className="flex items-center">
            {/* Home */}
            <a href="#" className="flex flex-col items-center justify-center px-3 py-1 text-gray-600 hover:text-gray-900 relative">
              <svg className="w-6 h-6" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"></path>
                <polyline points="9 22 9 12 15 12 15 22"></polyline>
              </svg>
              <span className="text-[10px] mt-0.5">Home</span>
              <div className="absolute bottom-0 left-0 right-0 h-[2px] bg-gray-900" />
            </a>

            {/* My Network */}
            <a href="#" className="flex flex-col items-center justify-center px-3 py-1 text-gray-600 hover:text-gray-900 relative">
              <svg className="w-6 h-6" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"></path>
                <circle cx="9" cy="7" r="4"></circle>
                <path d="M23 21v-2a4 4 0 0 0-3-3.87"></path>
                <path d="M16 3.13a4 4 0 0 1 0 7.75"></path>
              </svg>
              <span className="text-[10px] mt-0.5">My Network</span>
              <span className="absolute top-1 right-2 bg-red-500 text-white text-[10px] font-semibold rounded-full w-4 h-4 flex items-center justify-center">2</span>
            </a>

            {/* Jobs */}
            <a href="#" className="flex flex-col items-center justify-center px-3 py-1 text-gray-600 hover:text-gray-900">
              <svg className="w-6 h-6" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <rect x="2" y="7" width="20" height="14" rx="2" ry="2"></rect>
                <path d="M16 21V5a2 2 0 0 0-2-2h-4a2 2 0 0 0-2 2v16"></path>
              </svg>
              <span className="text-[10px] mt-0.5">Jobs</span>
            </a>

            {/* Messaging */}
            <a href="#" className="flex flex-col items-center justify-center px-3 py-1 text-gray-600 hover:text-gray-900">
              <svg className="w-6 h-6" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"></path>
              </svg>
              <span className="text-[10px] mt-0.5">Messaging</span>
            </a>

            {/* Notifications */}
            <a href="#" className="flex flex-col items-center justify-center px-3 py-1 text-gray-600 hover:text-gray-900">
              <svg className="w-6 h-6" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9"></path>
                <path d="M13.73 21a2 2 0 0 1-3.46 0"></path>
              </svg>
              <span className="text-[10px] mt-0.5">Notifications</span>
            </a>

            {/* Me */}
            <a href="#" className="flex flex-col items-center justify-center px-3 py-1 text-gray-600 hover:text-gray-900 border-r border-gray-300">
              <div className="relative">
                <img
                  src="https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=150&h=150&fit=crop"
                  alt="Profile"
                  className="w-6 h-6 rounded-full"
                />
              </div>
              <div className="flex items-center gap-0.5">
                <span className="text-[10px] mt-0.5">Me</span>
                <svg className="w-3 h-3" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <polyline points="6 9 12 15 18 9"></polyline>
                </svg>
              </div>
            </a>

            {/* For Business */}
            <a href="#" className="flex flex-col items-center justify-center px-3 py-1 text-gray-600 hover:text-gray-900">
              <svg className="w-6 h-6" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <rect x="3" y="3" width="7" height="7"></rect>
                <rect x="14" y="3" width="7" height="7"></rect>
                <rect x="14" y="14" width="7" height="7"></rect>
                <rect x="3" y="14" width="7" height="7"></rect>
              </svg>
              <div className="flex items-center gap-0.5">
                <span className="text-[10px] mt-0.5">For Business</span>
                <svg className="w-3 h-3" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <polyline points="6 9 12 15 18 9"></polyline>
                </svg>
              </div>
            </a>

            {/* Try Premium */}
            <a href="#" className="ml-2 px-3 py-1 text-[#915907] hover:bg-[#F8F0E4] rounded">
              <span className="text-xs font-medium underline">Try Premium for ₹0</span>
            </a>
          </nav>
        </div>
      </div>
    </header>
  );
}