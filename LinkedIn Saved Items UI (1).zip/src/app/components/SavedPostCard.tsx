import { MoreHorizontal, Globe } from 'lucide-react';

export interface SavedPostItem {
  id: string;
  author: {
    name: string;
    title: string;
    avatar: string;
    followers?: string;
  };
  content: string;
  timeAgo: string;
  thumbnailUrl?: string;
  date: Date;
}

interface SavedPostCardProps {
  post: SavedPostItem;
}

export function SavedPostCard({ post }: SavedPostCardProps) {
  return (
    <div className="bg-white border border-gray-200 hover:shadow-md transition-shadow">
      <div className="p-4">
        <div className="flex gap-3">
          {/* Left side - Profile and Thumbnail */}
          <div className="flex flex-col gap-2 flex-shrink-0">
            <img
              src={post.author.avatar}
              alt={post.author.name}
              className="w-12 h-12 rounded-full object-cover"
            />
            {post.thumbnailUrl && (
              <img
                src={post.thumbnailUrl}
                alt="Post preview"
                className="w-16 h-16 object-cover rounded border border-gray-200"
              />
            )}
          </div>

          {/* Right side - Content */}
          <div className="flex-1 min-w-0">
            {/* Author Info */}
            <div className="flex items-start justify-between mb-1">
              <div className="flex-1 min-w-0">
                <h3 className="font-semibold text-sm text-gray-900 hover:text-[#0A66C2] hover:underline cursor-pointer">
                  {post.author.name}
                </h3>
                {post.author.followers && (
                  <p className="text-xs text-gray-600">{post.author.followers}</p>
                )}
                <div className="flex items-center gap-1 mt-0.5">
                  <span className="text-xs text-gray-500">{post.timeAgo}</span>
                  <span className="text-gray-400">•</span>
                  <Globe className="w-3 h-3 text-gray-500" />
                </div>
              </div>
              <button className="text-gray-500 hover:bg-gray-100 p-1.5 rounded-full transition-colors">
                <MoreHorizontal className="w-5 h-5" />
              </button>
            </div>

            {/* Post Content */}
            <div className="mt-2">
              <p className="text-sm text-gray-900 leading-5">
                {post.content.length > 150 
                  ? post.content.substring(0, 150) + '...'
                  : post.content}
              </p>
              {post.content.length > 150 && (
                <button className="text-sm text-gray-600 hover:text-[#0A66C2] mt-1">
                  ...see more
                </button>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
