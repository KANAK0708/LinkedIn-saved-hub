import { Bookmark } from 'lucide-react';

export function LeftSidebar() {
  return (
    <aside className="w-[228px] flex-shrink-0">
      <div className="bg-white rounded-lg border border-gray-200">
        {/* Header */}
        <div className="p-3 border-b border-gray-200">
          <div className="flex items-center gap-2 text-sm">
            <Bookmark className="w-4 h-4 text-gray-600" />
            <span className="font-semibold text-gray-900">My items</span>
          </div>
        </div>

        {/* Menu Items */}
        <nav>
          <a
            href="#"
            className="flex items-center justify-between px-3 py-2.5 text-sm text-gray-700 hover:bg-gray-100 transition-colors"
          >
            <span>My jobs</span>
            <span className="text-gray-500">14</span>
          </a>
          <a
            href="#"
            className="flex items-center justify-between px-3 py-2.5 text-sm bg-gray-100 border-l-2 border-gray-900 font-medium text-gray-900"
          >
            <span>Saved posts and articles</span>
            <span className="text-gray-600">10+</span>
          </a>
        </nav>
      </div>
    </aside>
  );
}
