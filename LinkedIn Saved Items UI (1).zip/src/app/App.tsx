import { useState, useMemo } from 'react';
import { Search } from 'lucide-react';
import { TopNavbar } from './components/TopNavbar';
import { LeftSidebar } from './components/LeftSidebar';
import { RightSidebar } from './components/RightSidebar';
import { SavedPostCard } from './components/SavedPostCard';
import { savedPosts } from './components/savedPostsData';

export default function App() {
  const [activeTab, setActiveTab] = useState<'All' | 'Articles'>('All');

  // Filter items based on active tab
  const filteredPosts = useMemo(() => {
    // For now, show all posts since we don't have article-specific filtering
    // In a real app, posts would have a type field to distinguish articles
    return savedPosts;
  }, [activeTab]);

  return (
    <div className="min-h-screen bg-[#F4F2EE]" style={{ fontFamily: 'Inter, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif' }}>
      {/* Top Navigation */}
      <TopNavbar />
      
      {/* Main Container */}
      <div className="max-w-[1128px] mx-auto px-6 py-6">
        <div className="flex gap-6">
          {/* Left Sidebar */}
          <LeftSidebar />

          {/* Main Content */}
          <main className="flex-1 min-w-0">
            {/* Header */}
            <div className="mb-3">
              <h1 className="text-xl font-normal text-gray-900 mb-3">Saved Posts</h1>
              
              {/* Filter Pills */}
              <div className="flex gap-2">
                <button
                  onClick={() => setActiveTab('All')}
                  className={`px-4 py-1.5 rounded-full text-sm font-medium transition-colors ${
                    activeTab === 'All'
                      ? 'bg-[#057642] text-white'
                      : 'bg-white text-gray-700 border border-gray-300 hover:bg-gray-50'
                  }`}
                >
                  All
                </button>
                <button
                  onClick={() => setActiveTab('Articles')}
                  className={`px-4 py-1.5 rounded-full text-sm font-medium transition-colors ${
                    activeTab === 'Articles'
                      ? 'bg-[#057642] text-white'
                      : 'bg-white text-gray-700 border border-gray-300 hover:bg-gray-50'
                  }`}
                >
                  Articles
                </button>
                <button
                  className="p-2 rounded-full bg-white text-gray-700 border border-gray-300 hover:bg-gray-50 transition-colors"
                  aria-label="Search"
                >
                  <Search className="w-4 h-4" />
                </button>
              </div>
            </div>

            {/* Posts Feed */}
            <div className="space-y-0">
              {filteredPosts.map((post, index) => (
                <div key={post.id} className={index > 0 ? 'border-t border-gray-200' : ''}>
                  <SavedPostCard post={post} />
                </div>
              ))}
            </div>
          </main>

          {/* Right Sidebar */}
          <RightSidebar />
        </div>
      </div>
    </div>
  );
}